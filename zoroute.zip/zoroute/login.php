<?php
$message="";
$msg="";
$c="";
session_start();
if(isset($_POST["login"])) {
if(count($_POST)>0) {
$conn = mysql_connect("localhost","root","");
mysql_select_db("zoroute",$conn);
$result = mysql_query("SELECT * FROM register WHERE email='" . $_POST["email"] . "' and password = '". $_POST["password"]."'");
$row  = mysql_fetch_array($result);
if(is_array($row)) {
$_SESSION["email"] = $row['email'];
$_SESSION["user_name"] = $row['name'];
} else {
echo '<script language="javascript">';
	echo 'alert("Wrong User ID Or Password")';
echo '</script>';
}
}
}
if(isset($_SESSION["email"])) {
header("Location:blog.php");
}
?>


<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Welcome To Zoroute</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
</head>
<body>
<div class="container" style="padding-top:200px;">
<div class="row">
<form name="register" action="login.php" method="post">
<div class="col-lg-5 col-xs-12" style="box-shadow:2px 2px 2px 2px gray; padding-bottom:50px";>
<center><h4><b>Register</b></h4></center>
<table><tr><th><?php echo $msg ;?> </th></tr></table>
<div class="input-group">
<label class="input-group-addon" for="quantity"><b>Name</b></label>
<input type="text" name="name" class="form-control" id="name" required />
</div>
<br>
<div class="input-group">
<label class="input-group-addon" for="quantity"><b>Email</b></label>
<input type="text" name="email" class="form-control" id="email" required />
</div>
<br>
<div class="input-group">
<label class="input-group-addon" for="quantity"><b>Phone</b></label>
<input type="text" name="phone" class="form-control" id="email" required />
</div>
</br>
<div class="input-group">
<label class="input-group-addon" for="quantity"><b>Password</b></label>
<input type="password" name="password" class="form-control" value="" id="password" required />
</div>
<br>
<div class="input-group">
<label class="input-group-addon" for="quantity"><b>Confirm Password</b></label>
<input type="password" name="cpassword" class="form-control" value="" id="cpassword" required />
</div>
<br>
<button class="btn btn-success" name="register" OnClick="return login(); resetform();">Register</button>
</div>

	

	
</form>

<form name="login" action="login.php" method="post">
<div class="col-lg-5 col-lg-offset-1 col-xs-12" style="box-shadow:2px 2px 2px 2px gray; padding-bottom:50px";>
<center><h4><b>Login</b></h4></center>
<div class="input-group">
<label class="input-group-addon" for="quantity"><b>Email</b></label>
<input type="text"  name="email" class="form-control" id="password">
</div>
<br>
<div class="input-group">
<label class="input-group-addon" for="quantity"><b>Password</b></label>
<input type="password"name="password" class="form-control" id="password">
</div>
<br>
<button class="btn btn-info btn-sm"  name="login">Login</button>
</form>
</div>

</div>
</div>
	<script>
						
function login()
{
var a=document.forms[1].password.value;
var b=document.forms[1].cpassword.value;
if(a==b)
{
return true;
}
else 
{
alert("password and confirmpassword must be same");
return false;
}
}
function resetform()
{
	document.forms[1].reset();
}
</script>
</body>
<?php 
if(isset($_POST['register']))

{
	$c =0;
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoroute";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT  * FROM register";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
		 if($row['email']== $_POST['email'])
		 {
$c = $c+1; 
}
}}
 //prepare and bind
if($c ==0){
$stmt = $conn->prepare("INSERT INTO register (name,email,phone ,password , cpassword) VALUES ( ?,?, ?,?,?)");
$stmt->bind_param("sssss", $name, $email, $phone , $password, $cpassword);

// set parameters and execute
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];
$stmt->execute();
$stmt->close();

$msg="sucessful Now Login";
}
else{
	$msg="Email id already exist Please try Login";
}
$conn->close();
}			
	?>

</html>
