<?php 
$user_name="";
$email="";
session_start();


?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoroute";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}?>
<?php
$user="";
if(!empty($_SESSION["user_name"])) {
$user=$_SESSION["user_name"];
$email=$_SESSION["email"];
}
else{
	$user="Guest";
}
?>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Welcome To Zoroute</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">
<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
<body>
<div class="container">
<div class="row" style="padding-top:10px;">
<div class="col-lg-6 col-xs-12">
<h4><b>Welcome &nbsp <?php echo $user;?></b></h4>
</div>
<div class="col-lg-6 col-xs-12">
<ul class="nav nav-pills pull-right">
    <li class="active"><a href="login.php">Login/Register</a></li>
    <li><a href="logout.php">Log Out</a></li>
  </ul>
</div>
</div>
</div>
</br>
<div class="container">
<div class="row">
</div class="col-lg-12 col-xs-12" >
<div class="well well-sm" style="box-shadow:2px 2px 2px 2px gray;background-color:white;color:darkblue">
<center><h4><b>Welecom To Our Blog Portal</b></h4></center>
</div>
</div>
</div>
<div class="container">
<div class="row" style="box-shadow:2px 2px 2px 2px solid gray;">
<div class="col-lg-4 col-xs-12">
<img src="images/39.jpg" class="img-responsive img-thumbnail" />
</div>
<div class="col-lg-6 col-xs-12">
<p><b><i>it is a long established fact that a reader will be distracted by the readable content 
of a page when looking at its layout. 
The point of using Lorem Ipsum is that 
it has a more-or-less normal distribution 
of letters, as opposed to using 'Content here, 
content here', making it look like readable English. 
Many desktop publishing packages and web page editors 
now use Lorem Ipsum as their default model text, and a 
search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over 
the years, sometimes by accident, sometimes on purpose (injected humour and the like).
</i></b></p>

</div>
</div>
</br>
<div class="row">
<div class="col-lg-6 col-xs-12">
<h5>Written By</h5>
<p><img class="img-responsive img-circle" style="height:75px; width:75px;" src="images/39.jpg" />Nirbhay Singh</p>
</div>
</div>
<div class="row">
<?php 
$sql = "SELECT  * FROM comment ORDER BY id Desc";
						 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
	 
     while($row = $result->fetch_assoc()) {
		 ?>
		
<div class="col-lg- col-xs-12">
 <div class="well well sm">
 <?php echo $row['comment']; ?>
 
<div class="col-lg-2 pull-right">
<span class="badge"><?php echo $row['name'];?></span>
</div>
</div>
</div>
<?php }} ?>


</div>
<div class="row">

<form action="blog.php" method="post" name="blogform">
    <div class="form-group">
      <label for="comment">Comment:</label>
      <textarea class="form-control" rows="5" id="comment" name="comment"></textarea>
    </div>
	<button class="btn btn-Success btn-lg" name="submit">Submit</button>
  </form>
</div>
</div>
<?php 
if((isset($_POST['submit'])) && (!empty($_SESSION['user_name'])))
{


 //prepare and bind
$stmt = $conn->prepare("INSERT INTO comment (name,email,comment) VALUES ( ?,?,?)");
$stmt->bind_param("sss", $name, $email, $comment);

// set parameters and execute
$name = $_SESSION["user_name"];
$email = $_SESSION["email"];
$comment = $_POST["comment"];
$stmt->execute();
echo '<script language="javascript">';
	echo 'alert("Comment Upated Sucessfully")';
	echo '</script>';
$stmt->close();
$conn->close();

}


else if((isset($_POST['submit'])) && (empty($_SESSION['user_name'])))
{
	echo '<script language="javascript">';
	echo 'alert("Please Login To Comment")';
	echo '</script>';
}	
	?>

</body>
</html>